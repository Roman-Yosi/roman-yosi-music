export default function App() {
  return (
    <div style={{padding:"40px",fontFamily:"sans-serif",background:"#0f172a",minHeight:"100vh",color:"white"}}>
      <h1>MusicHub Full Project</h1>
      <p>Project React siap upload.</p>
    </div>
  )
}
